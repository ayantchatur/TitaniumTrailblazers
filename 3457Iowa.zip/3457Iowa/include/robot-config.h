using namespace vex;

extern brain Brain;

//To set up a motor called LeftFront here, you'd use
//extern motor LeftFront;

//Add your devices below, and don't forget to do the same in robot-config.cpp:
extern digital_out MatchLoader;
extern digital_out Descore;
extern motor IntakeMotor;
extern motor ScoreMotor;

void  vexcodeInit( void );