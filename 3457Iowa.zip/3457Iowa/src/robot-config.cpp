#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen.
brain  Brain;

digital_out MatchLoader = digital_out(Brain.ThreeWirePort.H);
digital_out Descore = digital_out(Brain.ThreeWirePort.C);

motor IntakeMotor = motor(PORT15, ratio6_1, false); // forward moves ball up
// motor RampMotor = motor(PORT15, ratio6_1, false);
motor ScoreMotor = motor(PORT17, ratio6_1, true); // forward moves ball up

//The motor constructor takes motors as (port, ratio, reversed), so for example
//motor LeftFront = motor(PORT1, ratio6_1, false);

//Add your devices below, and don't forget to do the same in robot-config.h:


void vexcodeInit( void ) {
  // nothing to initialize
}